namespace brazil
{
    using MySql.Data.MySqlClient;
    using System.Data;

    public partial class Form1 : Form
    {
        MySqlConnection conexa��o = new MySqlConnection();
        MySqlCommand comando = new MySqlCommand();

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string conexa��oA = "server=localhost;User Id=root;database=campeonatos_brasileiros;password=miguel1930;";
            string query = "SELECT id_serie, nome_serie, descricao FROM tb_serie;";
            using (MySqlConnection c = new MySqlConnection(conexa��oA))
            {
                try
                {
                    c.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter(query, c);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("erro");
                     }

 }
        }

            private void button1_Click(object sender, EventArgs e)
        {
            string conexa��oA = "server=localhost;User Id=root;database=campeonatos_brasileiros;password=miguel1930;";
            string query = "SELECT id_time, nome_time, estado, estadio FROM tb_time;";
            using (MySqlConnection c = new MySqlConnection(conexa��oA))
            {
                try
                {
                    c.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter(query, c);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView2.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("erro");
                }

            }

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
