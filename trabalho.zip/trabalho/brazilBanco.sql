CREATE DATABASE campeonatos_brasileiros;
USE campeonatos_brasileiros;

CREATE TABLE tb_serie (
    id_serie INT AUTO_INCREMENT PRIMARY KEY,
    nome_serie VARCHAR(2) NOT NULL UNIQUE,  
    descricao VARCHAR(100)                  
);

CREATE TABLE tb_time (
    id_time INT AUTO_INCREMENT PRIMARY KEY,
    nome_time VARCHAR(100) NOT NULL UNIQUE,
    estado CHAR(2) NOT NULL,                -- Ex: SP, RJ, RS...
    fundacao DATE,
    estadio VARCHAR(100),
    id_serie INT,
    FOREIGN KEY (id_serie) REFERENCES tb_serie(id_serie)
);

CREATE TABLE tb_campeonato (
    id_campeonato INT AUTO_INCREMENT PRIMARY KEY,
    ano YEAR NOT NULL,
    serie_id INT,
    FOREIGN KEY (serie_id) REFERENCES tb_serie(id_serie)
);

CREATE TABLE tb_time_campeonato (
    id_participacao INT AUTO_INCREMENT PRIMARY KEY,
    time_id INT,
    campeonato_id INT,
    posicao INT,    -- posição final no campeonato
    pontos INT,
    FOREIGN KEY (time_id) REFERENCES tb_time(id_time),
    FOREIGN KEY (campeonato_id) REFERENCES tb_campeonato(id_campeonato)
);

INSERT INTO tb_serie (nome_serie, descricao)
VALUES ('A', 'Série A do Campeonato Brasileiro'),
       ('B', 'Série B do Campeonato Brasileiro'),
       ('C', 'Série C do Campeonato Brasileiro'),
       ('D', 'Série D do Campeonato Brasileiro');
       
       INSERT INTO tb_time (nome_time, estado, fundacao, estadio, id_serie)
VALUES ('Flamengo', 'RJ', '1895-11-17', 'Maracanã', 1),
       ('Palmeiras', 'SP', '1914-08-26', 'Allianz Parque', 1),
       ('Corinthians', 'SP', '1910-09-01', 'Neo Química Arena', 1),
       ('Cruzeiro', 'MG', '1921-01-02', 'Mineirão', 2);
       
       
INSERT INTO tb_campeonato (ano, serie_id)
VALUES (2025, 1), (2025, 2);


INSERT INTO tb_time_campeonato (time_id, campeonato_id, posicao, pontos)
VALUES (1, 1, 2, 75),   -- Flamengo, Série A 2025
       (2, 1, 1, 80),   -- Palmeiras, Série A 2025
       (4, 2, 3, 65);   -- Cruzeiro, Série B 2025

